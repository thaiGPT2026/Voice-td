# PsychroVoice — app Android tính trạng thái không khí ẩm bằng giọng nói

## Cách build ra APK
1. Cài **Android Studio** (Hedgehog trở lên) và mở thư mục này (File → Open).
2. Đợi Gradle sync xong (lần đầu cần Internet để tải Android SDK 34 và thư viện).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. File APK nằm ở `app/build/outputs/apk/debug/app-debug.apk` → chép sang điện thoại và cài (cho phép cài từ nguồn không rõ).

Hoặc dùng dòng lệnh (đã có Android SDK):
```
./gradlew assembleDebug
```

## Yêu cầu trên điện thoại
- Android 7.0 (API 24) trở lên.
- Nhận dạng giọng nói dùng dịch vụ của Google (app Google / Speech Services). Lần đầu cần Internet; có thể tải gói tiếng Việt ngoại tuyến trong Cài đặt → Giọng nói.
- Đọc kết quả dùng Text-to-Speech của máy; nếu chưa có giọng tiếng Việt, cài **Speech Services by Google** và chọn tiếng Việt.

## Cấu trúc
- `app/src/main/assets/index.html` — toàn bộ giao diện, lõi tính toán ASHRAE và bộ phân tích câu nói tiếng Việt. Sửa file này là đủ để đổi tính năng.
- `app/src/main/java/vn/psychro/voice/MainActivity.java` — WebView + cầu nối `AndroidBridge` (startListening / stopListening / speak / stopSpeak).

## Cách nói
Luôn nói nhiệt độ bầu khô và **một** thông số nữa:
- "bầu khô 30 độ, độ ẩm 60 phần trăm"
- "bầu khô 25, độ chứa hơi 12 gam"
- "bầu khô 28, bầu ướt 22"
- "bầu khô 30, điểm sương 20"
- "bầu khô 30, entanpi 80"
- thêm "áp suất 95 kPa" nếu không ở mực nước biển.
