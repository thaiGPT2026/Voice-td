package vn.psychro.voice;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.Locale;

/** Vỏ Android cho app web: WebView + nhận dạng giọng nói + đọc kết quả bằng tiếng Việt. */
public class MainActivity extends AppCompatActivity {
    private static final int REQ_AUDIO = 1;
    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingSpeech = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        // Nạp trang từ assets qua https://appassets.androidplatform.net để Web API hoạt động đầy đủ
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("vi", "VN"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) {
                    Toast.makeText(this, "Thiếu giọng đọc tiếng Việt: cài Google Text-to-Speech / Speech Services", Toast.LENGTH_LONG).show();
                }
                if (pendingSpeech != null) { speakNow(pendingSpeech); pendingSpeech = null; }
            }
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
    }

    private void js(String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }
    private static String q(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\""; }

    private void speakNow(String text) {
        if (tts == null) return;
        if (!ttsReady) { pendingSpeech = text; return; }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "psychro");
    }

    private void startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            js("onSpeechError(\"chưa cấp quyền micro\")");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onSpeechError(\"máy chưa có dịch vụ nhận dạng giọng nói (cài Google app)\")");
            return;
        }
        if (tts != null) tts.stop();
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { js("onSpeechStarted()"); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float v) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() {}
                public void onError(int e) {
                    String m;
                    switch (e) {
                        case SpeechRecognizer.ERROR_NO_MATCH: case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: m = "không nghe thấy gì, thử lại"; break;
                        case SpeechRecognizer.ERROR_NETWORK: case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: m = "lỗi mạng (nhận dạng cần Internet hoặc gói tiếng Việt ngoại tuyến)"; break;
                        case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: m = "chưa cấp quyền micro"; break;
                        case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: m = "bộ nhận dạng đang bận"; break;
                        default: m = "lỗi nhận dạng mã " + e;
                    }
                    js("onSpeechError(" + q(m) + ")");
                }
                public void onResults(Bundle r) {
                    ArrayList<String> list = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) js("onSpeechResult(" + q(list.get(0)) + ")");
                    else js("onSpeechError(\"không nghe thấy gì\")");
                }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int i, Bundle b) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(i);
    }

    /** Hàm JavaScript gọi được: window.AndroidBridge.* */
    private class Bridge {
        @JavascriptInterface public void startListening(String lang) { runOnUiThread(MainActivity.this::startListening); }
        @JavascriptInterface public void stopListening() { runOnUiThread(() -> { if (recognizer != null) recognizer.cancel(); }); }
        @JavascriptInterface public void speak(String text) { runOnUiThread(() -> speakNow(text)); }
        @JavascriptInterface public void stopSpeak() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] g) {
        super.onRequestPermissionsResult(code, p, g);
        if (code == REQ_AUDIO && (g.length == 0 || g[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Cần quyền micro để nói với app", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
